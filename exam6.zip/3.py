from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("https://www.saucedemo.com/")

driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "password").send_keys("secret_sauce")
driver.find_element(By.ID, "login-button").click()

time.sleep(1)

descriptions = driver.find_elements(By.CLASS_NAME, "inventory_item_desc")

print()
for idx, desc in enumerate(descriptions, start=1):
    print(idx, desc.text)

driver.quit()