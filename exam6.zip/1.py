# 웹사이트의 페이지에서 원하는 데이터를 자동으로 수집하는 기술
# requests, BeautifulSoup, Selenium 활용  단, 저작권, 서비스 이용약관 확인할것