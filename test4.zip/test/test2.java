/**
 * 
 */
package egovframework.example.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import egovframework.example.dept.service.DeptService;
import lombok.extern.log4j.Log4j2;

/**
 * @author user
 *
 */
//@Log4j2
//@Controller
//public class test2 {
////	서비스 가져오기
//	@Autowired
//	private DeptService deptService; 
////			...
//			
//}
