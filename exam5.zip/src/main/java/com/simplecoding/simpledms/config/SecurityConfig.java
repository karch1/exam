package com.simplecoding.simpledms.config;

import jakarta.servlet.DispatcherType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

//  스프링 시큐리티 설정 파일
@Configuration                  // 자바파일을 설정파일로 사용할 수 있게 하는 어노테이션  
//                                  예) application.properties 파일처럼 사용
@EnableWebSecurity              // 스프링 시큐리티를 활성화하는 어노테이션
public class SecurityConfig {

//    스프링 : DB 패스워드는 암호화 해야한다.(암호화 라이브러리 설치)
//    스프링부트 : 암호화 라이브러리 포함됨.(스프링 시큐리티 안에 있음)
//     TODO : 목적 : 암호화 메소드
    @Bean           // IOC : 예) @Service 등 유사 생성자 DI 받으면된다
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

//    TODO : 목적 : 인증, 권한 설정 메소드
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
//        authorize(권한관리), authenticate(인증, 로그인)
        http.authorizeHttpRequests(auth -> auth
                .dispatcherTypeMatchers(DispatcherType.FORWARD).permitAll()
//                  jsp 태그중에 redirect 태그 허용
                .dispatcherTypeMatchers(DispatcherType.INCLUDE).permitAll()
//                  jsp 태그중에 jsp:include 태그 허용
                .requestMatchers("/auth/**", "/", "/erros","/css/**","/images/**","/js/**").permitAll()
//                  url 허용 주소 (로그인 없어도 가능)
                .requestMatchers("/admin/**").hasAuthority("ROLE_ADMIN")        
//                  admin 메뉴는 ROLE_ADMIN 권한 있는 사람만 볼 수 있음
                .anyRequest().authenticated()
//                  위를 제외한 다른 URL은 모두 로그인 해야 볼 수 있음
        );
    }

}
