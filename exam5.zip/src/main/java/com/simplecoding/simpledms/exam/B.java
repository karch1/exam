package com.simplecoding.simpledms.exam;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class B {
//    public class DeptController {
//        //        서비스 가져오기
//        private final DeptService deptService;
//    }
}
