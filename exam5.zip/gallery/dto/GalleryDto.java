package com.simplecoding.simpledms.gallery.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GalleryDto {
    private String uuid;                // 기본키 , 자바 uuid 사용
    private String galleryTitle;
    private String galleryFileUrl;      // 다운로드 URL(img 태그에 사용)

//    생성자(galleryTitle)
    public GalleryDto(String galleryTitle) {
        this.galleryTitle = galleryTitle;
    }
}
