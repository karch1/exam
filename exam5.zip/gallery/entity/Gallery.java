package com.simplecoding.simpledms.gallery.entity;

import com.simplecoding.simpledms.common.BaseTimeEntity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.*;

//  JPA 어노테이션
@Entity
@Table(name = "TB_GALLERY")
//  롬북 어노테이션
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(of = "uuid", callSuper = false)
public class Gallery extends BaseTimeEntity {

    @Id
    private String uuid;                // 기본키 , 자바 uuid 사용
    private String galleryTitle;
    @Lob
    private byte[] galleryData;         // 이미지(DB저장, BLOB)
    private String galleryFileUrl;      // 다운로드 URL(img 태그에 사용)
}
