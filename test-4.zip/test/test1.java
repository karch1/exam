/**
 * 
 */
package egovframework.example.test;

/**
 * @author user
 *	
	Model	데이터, 비즈니스 로직 (DB, 서비스, VO 등)
	View	사용자에게 보여지는 화면 (JSP, Thymeleaf 등)
	Controller	요청을 받아 Model과 View를 연결하는 중재자
 *	Spring MVC는 사용자 요청 → 컨트롤러 처리 → 모델 데이터 → 뷰로 결과 출력 구조를 가진, 깔끔한 웹 애플리케이션 구조
 */
public class test1 {

}
