/**
 * 
 */
package eaxm2;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author user
 *
 */
public class S03 {
	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);

		int b = a.nextInt();

		int[] c = new int[b];
		for (int i = 0; i < b; i++) {

			c[i] = a.nextInt();
		}
		Arrays.sort(c);

		for (int i : c) {
			System.out.printf(i + " ");
		}
	}
}
